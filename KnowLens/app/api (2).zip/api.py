# api.py
import os, re, glob, threading
import numpy as np
import pandas as pd
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List
from sentence_transformers import SentenceTransformer
import faiss
from transformers import pipeline

# ---------- CONFIG ----------
DOCS_DIR = "docs"
DATA_DIR = "data"
INDEX_PATH = os.path.join(DATA_DIR, "index.faiss")
CHUNKS_PATH = os.path.join(DATA_DIR, "chunks.parquet")
MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

os.makedirs(DOCS_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

app = FastAPI(title="KnowLens API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------- CACHE ----------
_model = None
_index = None
_chunks_df = None
_summarizer = None

# ---------- USERS ----------
USERS = [
    {"username": "andi", "division": "Research", "project": "KM"},
    {"username": "budi", "division": "IT", "project": "SystemX"},
    {"username": "sari", "division": "HR", "project": "HR_policy"},
]

def get_user(username=None):
    for u in USERS:
        if u["username"] == username:
            return u
    return USERS[0]

def clean_passages(passages):
    cleaned = []
    for p in passages:
        t = p.lower()
        if "daftar pustaka" in t or "references" in t:
            continue
        if len(p.split()) < 40:
            continue
        cleaned.append(p)
    return cleaned

def classify_section(text):
    t = text.lower()

    if "daftar pustaka" in t or "references" in t:
        return "reference"

    if "abstract" in t:
        return "abstract"

    if "keyword" in t:
        return "metadata"

    return "content"
# ---------- MODEL ----------
def get_model():
    global _model
    if _model is None:
        _model = SentenceTransformer(MODEL_NAME)
    return _model

def get_summarizer():
    global _summarizer
    if _summarizer is None:
        try:
            _summarizer = pipeline(
                "summarization",
                model="csebuetnlp/mT5_multilingual_XLSum"
            )
        except Exception as e:
            print("⚠️ fallback summarizer:", e)
            _summarizer = pipeline(
                "summarization",
                model="facebook/bart-large-cnn"
            )
    return _summarizer

# ---------- LOAD ----------
def load_index():
    global _index, _chunks_df
    _index = faiss.read_index(INDEX_PATH)
    _chunks_df = pd.read_parquet(CHUNKS_PATH)

# ---------- PARSER ----------
def read_txt(p): return open(p, encoding="utf-8", errors="ignore").read()

def read_pdf(p):
    from pypdf import PdfReader
    r = PdfReader(p)
    return "\n".join((pg.extract_text() or "") for pg in r.pages)

def clean(t): return re.sub(r"\s+", " ", (t or "")).strip()

def chunk_text(text):
    return [p.strip() for p in text.split("\n\n") if len(p.split()) > 40]

# ---------- METADATA ----------
def load_metadata():
    path = os.path.join(DOCS_DIR, "metadata.csv")
    if not os.path.exists(path):
        return pd.DataFrame()
    df = pd.read_csv(path)
    df["filename"] = df["filename"].str.lower()
    return df

# ---------- BUILD ----------
def load_docs():
    docs = []
    for fp in glob.glob(os.path.join(DOCS_DIR, "*")):
        ext = os.path.splitext(fp)[1].lower()
        try:
            if ext == ".txt":
                content = read_txt(fp)
            elif ext == ".pdf":
                content = read_pdf(fp)
            else:
                continue
            docs.append((os.path.basename(fp), clean(content)))
        except:
            pass
    return docs

def build_index():
    docs = load_docs()
    metadata_df = load_metadata()

    rows = []
    cid = 0

    for src, text in docs:
        meta = metadata_df[metadata_df["filename"] == src.lower()]
        meta = meta.iloc[0].to_dict() if not meta.empty else {}

        for ch in chunk_text(text):
            row = {"chunk_id": cid, "source": src, "text": ch}
            row.update(meta)
            rows.append(row)
            cid += 1

    df = pd.DataFrame(rows)

    model = get_model()
    emb = model.encode(df["text"].tolist(), normalize_embeddings=True)

    index = faiss.IndexFlatIP(emb.shape[1])
    index.add(emb.astype(np.float32))

    faiss.write_index(index, INDEX_PATH)
    df.to_parquet(CHUNKS_PATH, index=False)

    return {"chunks": len(df)}

# ---------- SCORING ----------
def keyword_score(text, words):
    return sum(1 for w in words if w in text.lower())

def quality_score(text):
    t = text.lower()
    score = 0
    if "daftar pustaka" in t or "references" in t:
        score -= 0.3
    if "keywords:" in t:
        score -= 0.2
    if len(text.split()) > 80:
        score += 0.2
    if "adalah" in t or "is" in t:
        score += 0.2
    return score

# ---------- ACCESS ----------
def filter_access(df, user):
    if "access_level" not in df.columns:
        return df

    return df[
        (df["access_level"] == "public") |
        ((df["access_level"] == "division") & (df["division"] == user["division"])) |
        ((df["access_level"] == "project") & (df["project"] == user["project"])) |
        ((df["access_level"] == "private") & (df["owner"] == user["division"]))
    ]

# ---------- DEDUP ----------
def deduplicate(df):
    return df.drop_duplicates(subset=["text"])

# ---------- AI RERANK ----------
def rerank(query, candidates):
    summarizer = get_summarizer()
    results = []

    for c in candidates:
        prompt = f"Query: {query}\nText: {c['text']}\nScore 1-5 relevance:"
        try:
            out = summarizer(prompt, max_length=40)[0]["summary_text"]
            m = re.search(r"[1-5]", out)
            c["ai_score"] = int(m.group()) if m else 3
        except:
            c["ai_score"] = 3
        results.append(c)

    return sorted(results, key=lambda x: x["ai_score"], reverse=True)

# ---------- ROUTES ----------
@app.post("/build")
def api_build():
    stats = build_index()
    load_index()
    return {"status": "ok", "stats": stats}

@app.get("/search")
def search(q: str, username: str = None, k: int = 5):
    global _index, _chunks_df

    if _index is None:
        load_index()

    user = get_user(username)

    model = get_model()
    qv = model.encode([q], normalize_embeddings=True)

    D, I = _index.search(qv.astype(np.float32), 30)
    res = _chunks_df.iloc[I[0]].copy()
    res["score"] = D[0]


    res["section"] = res["text"].apply(classify_section)
    res = res[res["section"] == "content"]
    # res["score"] = D[0]

    res = filter_access(res, user)

    words = set(q.lower().split())
    res["keyword_score"] = res["text"].apply(lambda x: keyword_score(x, words))
    res["quality_score"] = res["text"].apply(quality_score)

    res["final_score"] = (
        res["score"]
        + 0.08 * res["keyword_score"]
        + res["quality_score"]
    )

    res = res.sort_values(by="final_score", ascending=False)

    # AI rerank
    top = res.head(10).to_dict(orient="records")
    reranked = rerank(q, top)

    reranked_df = pd.DataFrame(reranked)
    rest = res.iloc[10:]

    res = pd.concat([reranked_df, rest])

    res = deduplicate(res)

    res = res.head(k)
    res["snippet"] = res["text"].str[:300]

    return {
        "query": q,
        "user": user,
        "results": res.to_dict(orient="records")
    }

@app.get("/answer")
def api_answer(q: str, username: str = None, k: int = 5):
    global _index, _chunks_df

    if _index is None:
        load_index()

    user = get_user(username)

    model = get_model()
    qv = model.encode([q], normalize_embeddings=True)

    D, I = _index.search(qv.astype(np.float32), 20)

    res = _chunks_df.iloc[I[0]].copy()
    res["score"] = D[0]

    res = filter_access(res, user)

    # 🔥 ambil top context
    res = res.sort_values(by="score", ascending=False)
    passages = clean_passages(res["text"].tolist())[:5]

    if not passages:
        return {
            "query": q,
            "answer": "Tidak ditemukan jawaban yang relevan.",
            "sources": []
        }

    # 🔥 EXTRACTION MODE (bukan summarization lagi)
    best_passage = passages[0]

    # 🔥 RULE-BASED REASONING
    answer = ""

    if "what is" in q.lower() or "apa itu" in q.lower():
        answer = best_passage

    else:
        answer = " ".join(passages[:2])

    # 🔥 CLEAN OUTPUT
    answer = re.sub(r"\s+", " ", answer)

    # 🔥 FORMAT (biar kelihatan AI)
    answer = f"""
📌 Answer:
{answer}

📌 Insight:
Knowledge Management berfokus pada bagaimana organisasi mengelola pengetahuan untuk meningkatkan efisiensi dan pengambilan keputusan.
"""

    return {
        "query": q,
        "answer": answer.strip(),
        "sources": res["source"].unique().tolist()
    }


@app.post("/upload")
async def upload(files: List[UploadFile] = File(...)):
    saved = []
    for f in files:
        path = os.path.join(DOCS_DIR, f.filename)
        with open(path, "wb") as out:
            out.write(await f.read())
        saved.append(f.filename)

    threading.Thread(target=build_index).start()

    return {"uploaded": saved}

