# api.py
import os, re, glob, threading
import numpy as np
import pandas as pd
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Optional
from sentence_transformers import SentenceTransformer
import faiss
from transformers import pipeline

# ---------- Config ----------
DOCS_DIR = "docs"
DATA_DIR = "data"
INDEX_PATH = os.path.join(DATA_DIR, "index.faiss")
CHUNKS_PATH = os.path.join(DATA_DIR, "chunks.parquet")
MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

USERS = [
    {"username": "andi", "division": "Research", "project": "KM"},
    {"username": "budi", "division": "IT", "project": "SystemX"},
    {"username": "sari", "division": "HR", "project": "HR_policy"},
]

CURRENT_USER = USERS[0]  # bisa diganti nanti

os.makedirs(DOCS_DIR, exist_ok=True)
os.makedirs(DATA_DIR, exist_ok=True)

app = FastAPI(title="KM Semantic Search API")
@app.on_event("startup")
def startup_event():
    print("🚀 Loading model & index...")
    get_model()
    load_index_and_chunks()
    print("✅ Ready")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# ---------- Cache ----------
_model: Optional[SentenceTransformer] = None
_index: Optional[faiss.Index] = None
_chunks_df: Optional[pd.DataFrame] = None
_summarizer = None

# ---------- Utils ----------
def normalize_filename(name):
    return name.strip().lower()

def get_current_user(username: str = None):
    for u in USERS:
        if u["username"] == username:
            return u
    return USERS[0]

def get_model():
    global _model
    if _model is None:
        _model = SentenceTransformer(MODEL_NAME)
    return _model

def get_summarizer():
    global _summarizer
    if _summarizer is None:
        _summarizer = pipeline(
            "summarization",
            model="facebook/bart-large-cnn",
            truncation=True
        )
    return _summarizer

def load_index_and_chunks():
    global _index, _chunks_df
    if not (os.path.exists(INDEX_PATH) and os.path.exists(CHUNKS_PATH)):
        raise FileNotFoundError("Index belum ada. Jalankan /build.")
    _index = faiss.read_index(INDEX_PATH)
    _chunks_df = pd.read_parquet(CHUNKS_PATH)

# ---------- Parsers ----------
def read_txt(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def read_pdf(path):
    from pypdf import PdfReader
    reader = PdfReader(path)
    return "\n".join((page.extract_text() or "") for page in reader.pages)

def read_docx(path):
    from docx import Document
    doc = Document(path)
    return "\n".join(p.text for p in doc.paragraphs)

def clean_text(t):
    return re.sub(r"\s+", " ", (t or "")).strip()

def chunk_text(text, max_tokens=180, overlap=30):
    words = text.split()
    chunks, start = [], 0
    while start < len(words):
        end = min(start + max_tokens, len(words))
        chunk = " ".join(words[start:end])
        if chunk:
            chunks.append(chunk)
        if end == len(words):
            break
        start = max(0, end - overlap)
    return chunks

# ---------- Data Loading ----------
def load_metadata():
    path = os.path.join(DOCS_DIR, "metadata.csv")
    if not os.path.exists(path):
        return pd.DataFrame()
    df = pd.read_csv(path)
    df["filename"] = df["filename"].apply(normalize_filename)
    return df

def load_docs():
    texts = []
    for fp in glob.glob(os.path.join(DOCS_DIR, "*")):
        ext = os.path.splitext(fp)[1].lower()
        try:
            if ext == ".txt":
                content = read_txt(fp)
            elif ext == ".pdf":
                content = read_pdf(fp)
            elif ext == ".docx":
                content = read_docx(fp)
            else:
                continue

            content = clean_text(content)
            if content:
                texts.append((os.path.basename(fp), content))

        except Exception as e:
            print(f"Skip {fp}: {e}")
    return texts

# ---------- Build ----------
def build_chunks(docs):
    metadata_df = load_metadata()
    rows, cid = [], 0

    for src, content in docs:
        meta = metadata_df[
            metadata_df["filename"] == normalize_filename(src)
        ]

        meta = meta.iloc[0].to_dict() if not meta.empty else {}

        for ch in chunk_text(content):
            row = {
                "chunk_id": cid,
                "source": src,
                "text": ch
            }
            row.update(meta)
            rows.append(row)
            cid += 1

    return pd.DataFrame(rows)

def build_index():
    docs = load_docs()
    if not docs:
        raise RuntimeError("Folder docs kosong.")

    df = build_chunks(docs)

    model = get_model()
    emb = model.encode(
        df["text"].tolist(),
        convert_to_numpy=True,
        normalize_embeddings=True
    )

    index = faiss.IndexFlatIP(emb.shape[1])
    index.add(emb.astype(np.float32))

    faiss.write_index(index, INDEX_PATH)
    df.to_parquet(CHUNKS_PATH, index=False)

    return {"chunks": len(df), "files": len(docs)}

# ---------- Access Control ----------
def filter_access(df, user_division=None, user_project=None):
    return df[
        (df["access_level"] == "public") |
        ((df["access_level"] == "division") & (df["division"] == user_division)) |
        ((df["access_level"] == "project") & (df["project"] == user_project)) |
        ((df["access_level"] == "private") & (df["owner"] == user_division))
    ]

# ---------- Routes ----------
@app.post("/build")
def api_build():
    stats = build_index()
    load_index_and_chunks()
    return {"status": "ok", "stats": stats}


@app.get("/search")
def api_search(
    q: str,
    username: str = None,   # 🔥 TAMBAHAN
    k: int = 5,
    division: str = None,
    year: int = None,
    country: str = None,
    access_level: str = None
):
    global _index, _chunks_df

    if _index is None:
        load_index_and_chunks()

    if not q.strip():
        raise HTTPException(400, "Query kosong")

    # 🔥 ambil user
    user = get_current_user(username)

    model = get_model()
    qv = model.encode([q], convert_to_numpy=True, normalize_embeddings=True)

    D, I = _index.search(qv.astype(np.float32), k * 5)

    res = _chunks_df.iloc[I[0]].copy()
    res["score"] = D[0]

    # 🔥 keyword boost sederhana
    query_words = set(q.lower().split())

    def keyword_score(text):
        words = set(text.lower().split())
        return len(query_words & words)

    res["keyword_score"] = res["text"].apply(keyword_score)

    # 🔥 combine score
    res["final_score"] = res["score"] + (0.05 * res["keyword_score"])

    # 🔥 sort ulang
    res = res.sort_values(by="final_score", ascending=False)

    # ---------- FILTER METADATA ----------
    if division:
        res = res[res["division"] == division]

    if year:
        res = res[res["year"] == year]

    if country:
        res = res[res["country"] == country]

    if access_level:
        res = res[res["access_level"] == access_level]

    # ---------- ACCESS CONTROL ----------
    res = filter_access(
        res,
        user_division=user["division"],
        user_project=user["project"]
    )

    # ambil top k
    res = res.head(k)

    res["snippet"] = res["text"].str[:300]

    return {
        "query": q,
        "user": user,   # 🔥 tampilkan user aktif
        "results": res.to_dict(orient="records")
    }


@app.get("/answer")
def api_answer(q: str, k: int = 5):
    global _index, _chunks_df

    if _index is None:
        load_index_and_chunks()

    model = get_model()
    qv = model.encode([q], convert_to_numpy=True, normalize_embeddings=True)

    D, I = _index.search(qv.astype(np.float32), k * 3)

    res = _chunks_df.iloc[I[0]].copy()
    passages = res["text"].tolist()

    text = f"""
        You are an expert in Knowledge Management.

        Answer the question clearly and structured:

        Question:
        {q}

        Use this context:
        {" ".join(passages)}

        Explain:
        1. Definition
        2. Importance
        3. Implementation in real organization
        4. Example if possible
        """

    summarizer = get_summarizer()
    summary = summarizer(text, max_length=150, min_length=40)[0]["summary_text"]

    return {
        "query": q,
        "answer": summary,
        "sources": res["source"].unique().tolist()
    }


@app.post("/upload")
async def upload(files: List[UploadFile] = File(...)):
    saved = []

    for f in files:
        path = os.path.join(DOCS_DIR, f.filename)
        with open(path, "wb") as out:
            out.write(await f.read())
        saved.append(f.filename)

    # auto rebuild (background)
    threading.Thread(target=build_index).start()

    return {"uploaded": saved, "status": "rebuilding index..."}